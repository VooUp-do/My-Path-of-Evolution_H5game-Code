<?php
// world_chat.php
include 'config.php';

// 检查用户是否登录
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// 获取用户信息
$stmt = $pdo->prepare("SELECT nickname, race FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user_info = $stmt->fetch(PDO::FETCH_ASSOC);

// 获取最近的世界聊天消息（最多50条）
$stmt = $pdo->prepare("
    SELECT 
        wcm.*,
        u.nickname,
        u.race,
        u.level
    FROM world_chat_messages wcm
    JOIN users u ON wcm.user_id = u.id
    ORDER BY wcm.created_at DESC
    LIMIT 50
");
$stmt->execute();
$messages = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC)); // 反转顺序，最新的在最后
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>我的进化之路 - 世界聊天</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
            color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            height: calc(100vh - 40px);
            display: flex;
            flex-direction: column;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            backdrop-filter: blur(10px);
        }
        .back-btn {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .back-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        .chat-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            backdrop-filter: blur(10px);
            overflow: hidden;
        }
        .messages-area {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .message-item {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 12px;
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }
        .message-user {
            font-weight: bold;
            font-size: 14px;
        }
        .message-time {
            font-size: 11px;
            color: #ccc;
        }
        .message-content {
            font-size: 14px;
            line-height: 1.4;
            word-wrap: break-word;
        }
        .input-area {
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        .input-form {
            display: flex;
            gap: 10px;
        }
        .message-input {
            flex: 1;
            padding: 12px;
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            color: #fff;
            font-size: 14px;
            resize: none;
            height: 50px;
        }
        .message-input:focus {
            outline: none;
            border-color: #4ecca3;
            box-shadow: 0 0 0 2px rgba(78, 204, 163, 0.3);
        }
        .send-btn {
            background: #4ecca3;
            border: none;
            border-radius: 8px;
            padding: 0 20px;
            color: #1a1a2e;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 60px;
        }
        .send-btn:hover {
            background: #3db393;
        }
        .send-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        .race-badge {
            display: inline-block;
            padding: 1px 4px;
            border-radius: 6px;
            font-size: 9px;
            font-weight: bold;
            margin-left: 5px;
        }
        .race-bug { background: #8bc34a; color: #1a1a2e; }
        .race-spirit { background: #9c27b0; color: white; }
        .race-ghost { background: #607d8b; color: white; }
        .race-human { background: #ff9800; color: #1a1a2e; }
        .race-god { background: #ffeb3b; color: #1a1a2e; }
        .level-badge {
            background: #4ecca3;
            color: #1a1a2e;
            padding: 1px 4px;
            border-radius: 6px;
            font-size: 9px;
            font-weight: bold;
            margin-left: 5px;
        }
        .online-count {
            font-size: 12px;
            color: #4ecca3;
        }
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #ccc;
        }
        .empty-icon {
            font-size: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        .system-message {
            text-align: center;
            color: #ffc107;
            font-size: 12px;
            font-style: italic;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <a href="social.php" class="back-btn">返回社交</a>
            <h2>世界聊天</h2>
            <div class="online-count">全服玩家</div>
        </div>

        <div class="chat-container">
            <div class="messages-area" id="messagesArea">
                <?php if (empty($messages)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">💬</div>
                        <div>还没有聊天消息</div>
                        <div style="font-size: 12px; margin-top: 10px;">快来发送第一条消息吧！</div>
                    </div>
                <?php else: ?>
                    <?php foreach ($messages as $message): ?>
                    <div class="message-item">
                        <div class="message-header">
                            <div class="message-user">
                                <?php echo htmlspecialchars($message['nickname']); ?>
                                <span class="level-badge">Lv.<?php echo $message['level']; ?></span>
                                <span class="race-badge race-<?php echo $message['race']; ?>">
                                    <?php 
                                    $race_names = ['bug' => '虫族', 'spirit' => '灵族', 'ghost' => '鬼族', 'human' => '人族', 'god' => '神族'];
                                    echo $race_names[$message['race']] ?? '未知';
                                    ?>
                                </span>
                            </div>
                            <div class="message-time">
                                <?php echo date('H:i', strtotime($message['created_at'])); ?>
                            </div>
                        </div>
                        <div class="message-content">
                            <?php echo htmlspecialchars($message['message']); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="input-area">
                <form class="input-form" id="messageForm">
                    <textarea class="message-input" id="messageInput" 
                              placeholder="输入消息... (最多200字)" 
                              maxlength="200" required></textarea>
                    <button type="submit" class="send-btn" id="sendBtn">发送</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const messagesArea = document.getElementById('messagesArea');
        const messageForm = document.getElementById('messageForm');
        const messageInput = document.getElementById('messageInput');
        const sendBtn = document.getElementById('sendBtn');

        // 自动滚动到底部
        function scrollToBottom() {
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }

        // 初始滚动到底部
        setTimeout(scrollToBottom, 100);

        // 发送消息
        messageForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const message = messageInput.value.trim();
            if (!message) return;

            // 禁用发送按钮
            sendBtn.disabled = true;
            sendBtn.textContent = '发送中...';

            try {
                const response = await fetch('api/send_world_message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        message: message
                    })
                });

                const result = await response.json();

                if (result.success) {
                    messageInput.value = '';
                    // 可以在这里添加新消息到聊天区域
                    // 实际应用中应该使用WebSocket实时更新
                    location.reload(); // 简单重载页面
                } else {
                    alert('发送失败: ' + result.message);
                }
            } catch (error) {
                alert('网络错误，请重试');
                console.error('Error:', error);
            } finally {
                sendBtn.disabled = false;
                sendBtn.textContent = '发送';
            }
        });

        // 自动刷新聊天（每10秒）
        setInterval(() => {
            // 在实际应用中应该使用WebSocket，这里简单重载
            // location.reload();
        }, 10000);

        // 输入框高度自适应
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });
    </script>
</body>
</html>