<?php
// admin_announcements.php - 简单的公告管理页面
include 'config.php';

// 检查管理员权限（这里简单演示，实际应该更严格的权限检查）
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $type = $_POST['type'] ?? 'info';
    $end_time = $_POST['end_time'] ?? '';
    
    if (!empty($title) && !empty($content)) {
        $stmt = $pdo->prepare("
            INSERT INTO system_announcements (title, content, type, end_time) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$title, $content, $type, $end_time ?: null]);
        
        $message = "公告发布成功！";
    }
}

// 获取所有公告
$stmt = $pdo->prepare("SELECT * FROM system_announcements ORDER BY created_at DESC");
$stmt->execute();
$all_announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>公告管理</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .form-group { margin: 10px 0; }
        label { display: block; margin: 5px 0; }
        input, textarea, select { width: 100%; padding: 8px; margin: 5px 0; }
        button { background: #4ecca3; color: white; padding: 10px 20px; border: none; cursor: pointer; }
        .announcement-list { margin-top: 30px; }
        .announcement-item { border: 1px solid #ddd; padding: 10px; margin: 10px 0; }
    </style>
</head>
<body>
    <h1>公告管理</h1>
    
    <?php if (isset($message)): ?>
        <div style="color: green;"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label>标题:</label>
            <input type="text" name="title" required>
        </div>
        <div class="form-group">
            <label>内容:</label>
            <textarea name="content" rows="4" required></textarea>
        </div>
        <div class="form-group">
            <label>类型:</label>
            <select name="type">
                <option value="info">普通公告</option>
                <option value="important">重要公告</option>
                <option value="warning">警告通知</option>
                <option value="update">更新公告</option>
            </select>
        </div>
        <div class="form-group">
            <label>结束时间 (可选):</label>
            <input type="datetime-local" name="end_time">
        </div>
        <button type="submit">发布公告</button>
    </form>
    
    <div class="announcement-list">
        <h2>所有公告</h2>
        <?php foreach ($all_announcements as $announcement): ?>
            <div class="announcement-item">
                <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                <p><?php echo htmlspecialchars($announcement['content']); ?></p>
                <small>类型: <?php echo $announcement['type']; ?> | 状态: <?php echo $announcement['is_active'] ? '活跃' : '关闭'; ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>