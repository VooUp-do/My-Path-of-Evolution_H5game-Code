<?php
// config.php
header('Content-Type: text/html; charset=utf-8');

$host = 'localhost';
$dbname = 'evolution_game';
$username = 'evolution_game';
$password = 'evolution_game';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

// 启动session
session_start();


// 签到配置
$signin_config = [
    'daily_rewards' => [
        1 => ['coins' => 30, 'exp' => 10],    // 第1天
        2 => ['coins' => 40, 'exp' => 30],    // 第2天  
        3 => ['coins' => 50, 'exp' => 50],   // 第3天
        4 => ['coins' => 60, 'exp' => 80],   // 第4天
        5 => ['coins' => 70, 'exp' => 120],   // 第5天
        6 => ['coins' => 80, 'exp' => 150],   // 第6天
        7 => ['coins' => 150, 'exp' => 300],   // 第7天（周奖励）
    ],
    'streak_bonus' => [
        7 => ['coins' => 200, 'exp' => 100],  // 连续7天额外奖励
        30 => ['coins' => 2500, 'exp' => 500] // 连续30天额外奖励
    ]
];

// 段位配置 - 优化为更适合星级显示的积分范围
$rank_config = [
    'ranks' => [
        [
            'name' => '平凡',
            'min_score' => 0,
            'max_score' => 199,  // 每40分一星
            'color' => '#6c757d',
            'bg_color' => 'rgba(108, 117, 125, 0.2)',
            'text_color' => '#ffffff'
        ],
        [
            'name' => '精英',
            'min_score' => 200,
            'max_score' => 599,  // 每80分一星
            'color' => '#28a745',
            'bg_color' => 'rgba(40, 167, 69, 0.2)',
            'text_color' => '#ffffff'
        ],
        [
            'name' => '史诗',
            'min_score' => 600,
            'max_score' => 1199, // 每120分一星
            'color' => '#6f42c1',
            'bg_color' => 'rgba(111, 66, 193, 0.2)',
            'text_color' => '#ffffff'
        ],
        [
            'name' => '传说',
            'min_score' => 1200,
            'max_score' => 1999, // 每160分一星
            'color' => '#fd7e14',
            'bg_color' => 'rgba(253, 126, 20, 0.2)',
            'text_color' => '#1a1a2e'
        ],
        [
            'name' => '神话',
            'min_score' => 2000,
            'max_score' => 2999, // 每200分一星
            'color' => '#dc3545',
            'bg_color' => 'rgba(220, 53, 69, 0.2)',
            'text_color' => '#ffffff'
        ],
        [
            'name' => '超神',
            'min_score' => 3000,
            'max_score' => 999999, // 每100分一星
            'color' => '#e83e8c',
            'bg_color' => 'rgba(232, 62, 140, 0.2)',
            'text_color' => '#ffffff'
        ]
    ]
];

// 获取详细的段位星数信息
function get_rank_info($score) {
    global $rank_config;
    
    $score = max(0, $score);
    
    foreach ($rank_config['ranks'] as $rank) {
        if ($score >= $rank['min_score'] && $score <= $rank['max_score']) {
            // 计算详细的星级信息
            if ($rank['name'] === '超神') {
                // 超神段位：每100积分一颗星
                $stars = floor(($score - $rank['min_score']) / 100) + 1;
                $current_progress = ($score - $rank['min_score']) % 100;
                $max_progress = 100;
                $max_stars = 999; // 理论上无限
            } else {
                // 其他段位：1-5星
                $range = $rank['max_score'] - $rank['min_score'] + 1;
                $progress = $score - $rank['min_score'];
                $stars_per_level = 5; // 每个段位5星
                $points_per_star = $range / $stars_per_level;
                
                $stars = floor($progress / $points_per_star) + 1;
                $stars = min($stars_per_level, max(1, $stars));
                $current_progress = $progress % $points_per_star;
                $max_progress = $points_per_star;
                $max_stars = $stars_per_level;
            }
            
            return [
                'name' => $rank['name'],
                'color' => $rank['color'],
                'bg_color' => $rank['bg_color'],
                'text_color' => $rank['text_color'],
                'score' => $score,
                'min_score' => $rank['min_score'],
                'max_score' => $rank['max_score'],
                'stars' => $stars,
                'max_stars' => $max_stars,
                'current_progress' => $current_progress,
                'max_progress' => $max_progress,
                'progress_percent' => ($current_progress / $max_progress) * 100,
                'display_text' => $rank['name'] . $stars . '星'
            ];
        }
    }
    
    // 默认返回最低段位
    return get_rank_info(0);
}

// 获取下一个段位信息
function get_next_rank_info($current_score) {
    global $rank_config;
    
    $current_rank = get_rank_info($current_score);
    $current_index = array_search($current_rank['name'], array_column($rank_config['ranks'], 'name'));
    
    if ($current_index < count($rank_config['ranks']) - 1) {
        $next_rank = $rank_config['ranks'][$current_index + 1];
        $needed_score = $next_rank['min_score'] - $current_score;
        
        return [
            'name' => $next_rank['name'],
            'color' => $next_rank['color'],
            'needed_score' => max(0, $needed_score),
            'min_score' => $next_rank['min_score']
        ];
    }
    
    // 已经是最高段位
    return null;
}
?>