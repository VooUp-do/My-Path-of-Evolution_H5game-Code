<?php
// api/login.php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => '无效的请求方法']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => '请填写所有字段']);
    exit;
}

try {
    // 查找用户
    $stmt = $pdo->prepare("SELECT id, nickname, username, password, race, level FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        // 登录成功，设置session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['nickname'] = $user['nickname'];
        $_SESSION['race'] = $user['race'];
        $_SESSION['level'] = $user['level'];
        
        echo json_encode([
            'success' => true, 
            'message' => '登录成功',
            'user' => [
                'id' => $user['id'],
                'nickname' => $user['nickname'],
                'race' => $user['race']
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => '账号或密码错误']);
    }
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => '数据库错误: ' . $e->getMessage()]);
}
?>