<?php
// api/get_social_data.php
include '../config.php';

// 设置JSON头
header('Content-Type: application/json');

// 检查用户是否登录
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // 获取好友数量
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as friend_count 
        FROM friends 
        WHERE user_id = ? AND status = 'accepted'
    ");
    $stmt->execute([$user_id]);
    $friend_count = $stmt->fetchColumn();

    // 获取待处理的好友请求数量
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as request_count 
        FROM friend_requests 
        WHERE to_user_id = ? AND status = 'pending'
    ");
    $stmt->execute([$user_id]);
    $request_count = $stmt->fetchColumn();

    // 获取未读消息数量
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as unread_count 
        FROM chat_messages 
        WHERE to_user_id = ? AND is_read = 0
    ");
    $stmt->execute([$user_id]);
    $unread_count = $stmt->fetchColumn();

    // 返回数据
    echo json_encode([
        'success' => true,
        'data' => [
            'friend_count' => (int)$friend_count,
            'request_count' => (int)$request_count,
            'unread_count' => (int)$unread_count
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => '获取数据失败: ' . $e->getMessage()
    ]);
}
?>