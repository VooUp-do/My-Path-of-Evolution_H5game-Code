<?php
// api/send_world_message.php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => '无效的请求方法']);
    exit;
}

// 检查用户是否登录
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$message = trim($input['message'] ?? '');

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => '消息内容不能为空']);
    exit;
}

if (strlen($message) > 200) {
    echo json_encode(['success' => false, 'message' => '消息长度不能超过200字']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // 插入世界聊天消息
    $stmt = $pdo->prepare("
        INSERT INTO world_chat_messages (user_id, message) 
        VALUES (?, ?)
    ");
    $stmt->execute([$user_id, $message]);
    
    echo json_encode([
        'success' => true, 
        'message' => '消息发送成功'
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => '发送失败: ' . $e->getMessage()]);
}
?>