<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>我的进化之路 - 登录</title>
    <style>
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            background: linear-gradient(to bottom, #1a1a2e, #16213e);
            color: #fff;
            margin: 0;
            padding: 20px;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            width: 90%;
            max-width: 400px;
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #4ecca3;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        .tab-container {
            margin-bottom: 20px;
        }
        .tab {
            display: flex;
            border-bottom: 1px solid #4ecca3;
        }
        .tab button {
            flex: 1;
            background: none;
            border: none;
            color: #fff;
            padding: 12px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .tab button.active {
            color: #4ecca3;
            border-bottom: 3px solid #4ecca3;
            font-weight: bold;
        }
        .tab button:hover:not(.active) {
            background: rgba(78, 204, 163, 0.1);
        }
        .form-container {
            display: none;
        }
        .form-container.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 14px;
            margin: 8px 0;
            box-sizing: border-box;
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        input:focus {
            outline: none;
            border-color: #4ecca3;
            box-shadow: 0 0 0 2px rgba(78, 204, 163, 0.3);
            background: rgba(255, 255, 255, 0.2);
        }
        input::placeholder {
            color: #ccc;
        }
        .input-group {
            position: relative;
            margin-bottom: 5px;
        }
        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #4ecca3, #3db393);
            border: none;
            border-radius: 8px;
            color: #1a1a2e;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 15px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(78, 204, 163, 0.4);
        }
        .submit-btn:active {
            transform: translateY(0);
        }
        .submit-btn.loading {
            pointer-events: none;
            opacity: 0.8;
        }
        .submit-btn.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 20px;
            height: 20px;
            margin: -10px 0 0 -10px;
            border: 2px solid transparent;
            border-top: 2px solid #1a1a2e;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .message {
            text-align: center;
            margin-top: 15px;
            padding: 10px;
            border-radius: 6px;
            font-size: 14px;
            min-height: 20px;
            transition: all 0.3s ease;
        }
        .message.error {
            background: rgba(255, 107, 107, 0.2);
            color: #ff6b6b;
            border: 1px solid rgba(255, 107, 107, 0.3);
        }
        .message.success {
            background: rgba(78, 204, 163, 0.2);
            color: #4ecca3;
            border: 1px solid rgba(78, 204, 163, 0.3);
        }
        .rules {
            margin-top: 20px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            font-size: 12px;
            line-height: 1.4;
            color: #ccc;
        }
        .rules h3 {
            margin: 0 0 8px 0;
            color: #4ecca3;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>我的进化之路</h1>
        <div class="tab-container">
            <div class="tab">
                <button class="tab-link active" onclick="openTab(event, 'login')">登录</button>
                <button class="tab-link" onclick="openTab(event, 'register')">注册</button>
            </div>
        </div>

        <form id="loginForm" class="form-container active" onsubmit="return login(event);">
            <div class="input-group">
                <input type="text" name="username" placeholder="请输入账号" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="请输入密码" required>
            </div>
            <button type="submit" class="submit-btn" id="loginBtn">
                进入进化
            </button>
            <div id="loginMessage" class="message"></div>
        </form>

        <form id="registerForm" class="form-container" onsubmit="return register(event);">
            <div class="input-group">
                <input type="text" name="nickname" placeholder="请输入昵称" required>
            </div>
            <div class="input-group">
                <input type="text" name="username" placeholder="请输入账号（至少4位）" required minlength="4">
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="请输入密码（至少6位）" required minlength="6">
            </div>
            <button type="submit" class="submit-btn" id="registerBtn">
                开始进化
            </button>
            <div id="registerMessage" class="message"></div>
        </form>

        <div class="rules">
            <h3>游戏说明</h3>
            <p>• 注册后可选择五大种族之一开始进化</p>
            <p>• 每个种族都有独特的角色和天赋</p>
            <p>• 通过战斗获得经验、积分和金币</p>
            <p>• 不断提升段位，登上排行榜巅峰</p>
        </div>
    </div>

    <script>
        let currentTab = 'login';

        function openTab(evt, tabName) {
            if (currentTab === tabName) return;
            
            currentTab = tabName;
            const tabcontent = document.getElementsByClassName("form-container");
            const tablinks = document.getElementsByClassName("tab-link");
            
            // 隐藏所有表单
            for (let i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            
            // 更新标签页状态
            for (let i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            
            // 显示目标表单
            document.getElementById(tabName + "Form").classList.add("active");
            evt.currentTarget.classList.add("active");
            
            // 清空所有消息
            clearMessages();
        }

        function clearMessages() {
            document.getElementById('loginMessage').textContent = '';
            document.getElementById('loginMessage').className = 'message';
            document.getElementById('registerMessage').textContent = '';
            document.getElementById('registerMessage').className = 'message';
        }

        function setLoading(button, isLoading) {
            if (isLoading) {
                button.classList.add('loading');
                button.disabled = true;
            } else {
                button.classList.remove('loading');
                button.disabled = false;
            }
        }

        async function login(event) {
            event.preventDefault();
            const form = document.getElementById('loginForm');
            const messageEl = document.getElementById('loginMessage');
            const submitBtn = document.getElementById('loginBtn');

            // 清空之前的信息
            messageEl.textContent = '';
            messageEl.className = 'message';
            
            // 设置加载状态
            setLoading(submitBtn, true);

            try {
                const formData = new FormData(form);
                const response = await fetch('api/login.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    messageEl.textContent = '登录成功！正在进入进化世界...';
                    messageEl.className = 'message success';
                    
                    // 延迟跳转让用户看到成功消息
                    setTimeout(() => {
                        window.location.href = 'dashboard.php';
                    }, 1500);
                } else {
                    messageEl.textContent = result.message || '登录失败，请检查账号密码！';
                    messageEl.className = 'message error';
                }
            } catch (error) {
                messageEl.textContent = '网络连接错误，请检查网络后重试！';
                messageEl.className = 'message error';
                console.error('Login Error:', error);
            } finally {
                setLoading(submitBtn, false);
            }
        }

        async function register(event) {
            event.preventDefault();
            const form = document.getElementById('registerForm');
            const messageEl = document.getElementById('registerMessage');
            const submitBtn = document.getElementById('registerBtn');

            // 清空之前的信息
            messageEl.textContent = '';
            messageEl.className = 'message';
            
            // 设置加载状态
            setLoading(submitBtn, true);

            try {
                const formData = new FormData(form);
                const response = await fetch('api/register.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    messageEl.textContent = '注册成功！请使用账号密码登录。';
                    messageEl.className = 'message success';
                    
                    // 清空注册表单
                    form.reset();
                    
                    // 3秒后自动切换到登录页
                    setTimeout(() => {
                        // 找到登录标签页按钮并触发点击
                        document.querySelector('.tab-link').click();
                    }, 3000);
                } else {
                    messageEl.textContent = result.message || '注册失败，请重试！';
                    messageEl.className = 'message error';
                }
            } catch (error) {
                messageEl.textContent = '网络连接错误，请检查网络后重试！';
                messageEl.className = 'message error';
                console.error('Register Error:', error);
            } finally {
                setLoading(submitBtn, false);
            }
        }

        // 输入时清空错误信息
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', function() {
                const messageEl = this.closest('form').querySelector('.message');
                if (messageEl.textContent) {
                    messageEl.textContent = '';
                    messageEl.className = 'message';
                }
            });
        });
    </script>
<!-- 系统公告弹窗 -->
<div class="announcement-modal" id="announcementModal">
    <div class="announcement-content">
        <div class="announcement-header">
            <h3>系统公告</h3>
            <button class="close-btn" onclick="closeAnnouncement()">×</button>
        </div>
        <div class="announcement-body" id="announcementBody">
            <!-- 公告内容将通过JavaScript动态加载 -->
        </div>
        <div class="announcement-footer">
            <label class="dont-show-again">
                <input type="checkbox" id="dontShowAgain"> 今日不再显示
            </label>
            <button class="confirm-btn" onclick="closeAnnouncement()">我知道了</button>
        </div>
    </div>
</div>

<script>
// 公告功能
let announcements = [];

// 加载公告
async function loadAnnouncements() {
    try {
        const response = await fetch('api/get_announcements.php');
        const result = await response.json();
        
        if (result.success && result.announcements.length > 0) {
            announcements = result.announcements;
            showAnnouncements();
        }
    } catch (error) {
        console.error('加载公告失败:', error);
    }
}

// 显示公告
function showAnnouncements() {
    // 检查是否今日不再显示
    const dontShow = localStorage.getItem('dontShowAnnouncements');
    const today = new Date().toDateString();
    
    if (dontShow === today) {
        return;
    }
    
    const modal = document.getElementById('announcementModal');
    const body = document.getElementById('announcementBody');
    
    let html = '';
    announcements.forEach((announcement, index) => {
        const typeClass = getTypeClass(announcement.type);
        const endTime = announcement.end_time ? new Date(announcement.end_time).toLocaleDateString() : '长期有效';
        
        html += `
            <div class="announcement-item ${typeClass}">
                <div class="announcement-title">
                    <span class="type-badge">${getTypeBadge(announcement.type)}</span>
                    ${announcement.title}
                </div>
                <div class="announcement-text">${announcement.content}</div>
                <div class="announcement-meta">
                    有效期至: ${endTime}
                </div>
                ${index < announcements.length - 1 ? '<hr>' : ''}
            </div>
        `;
    });
    
    body.innerHTML = html;
    modal.style.display = 'flex';
    
    // 添加动画
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

// 获取类型样式
function getTypeClass(type) {
    const classes = {
        'important': 'announcement-important',
        'warning': 'announcement-warning',
        'update': 'announcement-update',
        'info': 'announcement-info'
    };
    return classes[type] || 'announcement-info';
}

// 获取类型徽章
function getTypeBadge(type) {
    const badges = {
        'important': '重要',
        'warning': '注意',
        'update': '更新',
        'info': '公告'
    };
    return badges[type] || '公告';
}

// 关闭公告
function closeAnnouncement() {
    const modal = document.getElementById('announcementModal');
    const dontShowCheckbox = document.getElementById('dontShowAgain');
    
    if (dontShowCheckbox.checked) {
        const today = new Date().toDateString();
        localStorage.setItem('dontShowAnnouncements', today);
    }
    
    modal.classList.remove('active');
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

// 页面加载完成后显示公告
document.addEventListener('DOMContentLoaded', function() {
    // 延迟1秒显示公告，让页面先加载完成
    setTimeout(loadAnnouncements, 1000);
});

// 点击外部关闭
document.getElementById('announcementModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeAnnouncement();
    }
});
</script>

<style>
/* 公告弹窗样式 */
.announcement-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    z-index: 10000;
    justify-content: center;
    align-items: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.announcement-modal.active {
    opacity: 1;
}

.announcement-content {
    background: linear-gradient(135deg, #1a1a2e, #16213e);
    border: 2px solid #4ecca3;
    border-radius: 15px;
    width: 90%;
    max-width: 500px;
    max-height: 80vh;
    overflow: hidden;
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.announcement-modal.active .announcement-content {
    transform: scale(1);
}

.announcement-header {
    background: linear-gradient(135deg, #4ecca3, #3db393);
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.announcement-header h3 {
    margin: 0;
    color: #1a1a2e;
    font-size: 18px;
    font-weight: bold;
}

.close-btn {
    background: none;
    border: none;
    color: #1a1a2e;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.3s ease;
}

.close-btn:hover {
    background: rgba(26, 26, 46, 0.2);
}

.announcement-body {
    padding: 20px;
    max-height: 400px;
    overflow-y: auto;
}

.announcement-item {
    margin-bottom: 15px;
}

.announcement-item:last-child {
    margin-bottom: 0;
}

.announcement-title {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.type-badge {
    font-size: 12px;
    padding: 2px 8px;
    border-radius: 10px;
    font-weight: bold;
}

.announcement-text {
    font-size: 14px;
    line-height: 1.5;
    color: #e0e0e0;
    margin-bottom: 8px;
}

.announcement-meta {
    font-size: 12px;
    color: #888;
    text-align: right;
}

.announcement-important .type-badge {
    background: #ff6b6b;
    color: white;
}

.announcement-warning .type-badge {
    background: #ffc107;
    color: #1a1a2e;
}

.announcement-update .type-badge {
    background: #4ecca3;
    color: #1a1a2e;
}

.announcement-info .type-badge {
    background: #6c757d;
    color: white;
}

.announcement-footer {
    padding: 15px 20px;
    background: rgba(255, 255, 255, 0.05);
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.dont-show-again {
    font-size: 12px;
    color: #ccc;
    display: flex;
    align-items: center;
    gap: 5px;
    cursor: pointer;
}

.confirm-btn {
    background: #4ecca3;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    color: #1a1a2e;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
}

.confirm-btn:hover {
    background: #3db393;
    transform: translateY(-2px);
}

/* 滚动条样式 */
.announcement-body::-webkit-scrollbar {
    width: 6px;
}

.announcement-body::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 3px;
}

.announcement-body::-webkit-scrollbar-thumb {
    background: #4ecca3;
    border-radius: 3px;
}

.announcement-body::-webkit-scrollbar-thumb:hover {
    background: #3db393;
}

hr {
    border: none;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    margin: 15px 0;
}
</style>
    
</body>
</html>